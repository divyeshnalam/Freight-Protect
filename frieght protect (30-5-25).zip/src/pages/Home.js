import React from 'react';
// import AboutUs from '../components/AboutUs';
import BannerCarousel from '../components/BannerCarousel';
import Help from '../components/Help';
import Trusted from '../components/Trusted';
import '../styles.css';

function Home() {
  return (
    <div className="home">
      <BannerCarousel />
      <Help />
      <Trusted/>
        {/* <AboutUs /> */}
    </div>
  );
}

export default Home;