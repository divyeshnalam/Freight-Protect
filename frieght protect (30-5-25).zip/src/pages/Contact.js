import React, { useState } from "react";
import '../styles.css';

const companyTypesList = ["Carrier", "Shipper", "3PL / Broker", "Tech Provider", "Other"];

const initialForm = {
  firstName: "",
  lastName: "",
  companyName: "",
  workEmail: "",
  companyTypes: [],
  mobilePhone: "",
};

function Contact() {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      const updatedTypes = checked
        ? [...form.companyTypes, value]
        : form.companyTypes.filter((v) => v !== value);
      setForm({ ...form, companyTypes: updatedTypes });
    } else {
      setForm({ ...form, [name]: value });
    }
  };

  const handleBlur = (e) => {
    setTouched({ ...touched, [e.target.name]: true });
  };

  const validate = () => {
    const errs = {};
    if (!form.firstName.trim()) errs.firstName = "First name is required.";
    if (!form.lastName.trim()) errs.lastName = "Last name is required.";
    if (!form.companyName.trim()) errs.companyName = "Company name is required.";
    if (!form.workEmail.trim()) {
      errs.workEmail = "Work email is required.";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(form.workEmail)) {
      errs.workEmail = "Invalid email format.";
    }
    if (form.companyTypes.length === 0) errs.companyTypes = "Select at least one company type.";
    if (!form.mobilePhone.trim()) {
      errs.mobilePhone = "Phone number is required.";
    } else if (!/^[\d \-+()]+$/.test(form.mobilePhone)) {
      errs.mobilePhone = "Invalid phone number.";
    }
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validate();
    setErrors(validation);
    setTouched(Object.keys(form).reduce((acc, key) => ({ ...acc, [key]: true }), {}));
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
    }
  };

  const renderInput = (label, name, type = "text") => (
    <div className="form-group">
      <label className="form-label">{label}*</label>
      <input
        name={name}
        type={type}
        className={`input${errors[name] && touched[name] ? " input-error" : ""}`}
        value={form[name]}
        onChange={handleChange}
        onBlur={handleBlur}
        required
      />
      {errors[name] && touched[name] && <div className="form-error">{errors[name]}</div>}
    </div>
  );

  return (
    <div className="contact-section">
        <div className="contact-banner">
          <h1 className="contact-header">
            <span>Contact</span> us
          </h1>
        </div>
      <div className="container">
      <div className="form-wrapper">
        <h2 className="form-title"><span>Get in</span> touch with us</h2>
        <form className="form" onSubmit={handleSubmit} noValidate>
          <div className="form-row">
            {renderInput("First Name", "firstName")}
            {renderInput("Last Name", "lastName")}
          </div>

          <div className="form-row">
            {renderInput("Company Name", "companyName")}
            {renderInput("Work Email", "workEmail", "email")}
          </div>

          <div className="form-section">
            <label className="form-label">Company Type*</label>
            <div className="checkbox-group">
              {companyTypesList.map((type) => (
                <label key={type} className="checkbox-label">
                  <input
                    type="checkbox"
                    name="companyTypes"
                    value={type}
                    onChange={handleChange}
                    checked={form.companyTypes.includes(type)}
                  />
                  {type}
                </label>
              ))}
            </div>
            {errors.companyTypes && touched.companyTypes && (
              <div className="form-error">{errors.companyTypes}</div>
            )}
          </div>

          {renderInput("Mobile Phone Number", "mobilePhone")}

          <div className="static-recaptcha">
            <p>protected by reCAPTCHA</p>
            <div className="recaptcha-logos">
              <img src="https://www.gstatic.com/recaptcha/api2/logo_48.png" alt="reCAPTCHA" />
              <span>Privacy - Terms</span>
            </div>
          </div>

          <button type="submit" className="submit-btn">Connect with Freight</button>

          {submitted && <p className="success-message">Your query has been submitted.</p>}
        </form>
      </div>
      </div>
    </div>
  );
}

export default Contact;
