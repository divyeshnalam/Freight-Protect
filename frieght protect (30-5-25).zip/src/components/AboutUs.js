import React from 'react';
import banner3 from '../assets/img/banner-slider03.png';
import '../styles.css';

const AboutUs = () => {

  return (
    <section className="aboutUs" id="aboutUs">
      <img src="/images/about-top-img.png" alt="" className="abouTop" />
      <div className="aboutContainer">
        <div className="aboutContentWrapper">
          <div
            className="aboutText"
            data-aos="fade-right"
            data-aos-delay="50"
            data-aos-duration="1000"
          >
            <div className="subtitle">About US</div>
            <div className="title">
              Our passion at <span>Freight Protect</span> is  accessorial identification service for the{' '}
              <span>LTL Industry.</span>
            </div>
            <p>
              Founded in late 2025, <span>Freight Protect</span> is your trusted partner for accessorial identification. 
              We provide streamlined services tailored to you business's requirements. Enjoy accessorial fee transparency, 
              easy tracking & world-class support.
            </p>
            <a href="/about" className="read-more1">
              Read More About Us
            </a>
          </div>

          <div
            className="aboutImage"
            data-aos="fade-left"
            data-aos-delay="50"
            data-aos-duration="1000"
          >
            <img src={banner3} alt="About Freight Protect" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
