import React from 'react';
import 'aos/dist/aos.css';

import technologiesTop from '../assets/img/technologiesTop.png';
import techBubbleImg1 from '../assets/img/Technologies06.png';
import techBubbleImg1b from '../assets/img/Technologies1.png';
import techBubbleImg2 from '../assets/img/Technologies02.png';
import techBubbleImg2b from '../assets/img/Technologies2.png';
import techBubbleImg3 from '../assets/img/Technologies03.png';
import techBubbleImg3b from '../assets/img/Technologies3.png';

import '../styles.css';


const technologiesBubbles = [
  {
    id: 'webAppDevelopment',
    mainImg: techBubbleImg1,
    bottomImg: techBubbleImg1b,
    title: <span>Company A</span>,
    aos: 'fade-right',
    delay: 40,
  },
  {
    id: 'apiDevelopment',
    mainImg: techBubbleImg2,
    bottomImg: techBubbleImg2b,
    title: <> <span>Company B</span> </>,
    aos: 'fade-down',
    delay: 70,
  },
  {
    id: 'flexieLab',
    mainImg: techBubbleImg3,
    bottomImg: techBubbleImg3b,
    title: <> <span>Company C</span> </>,
    aos: 'fade-right',
    delay: 110,
  },
];

const Technologies = () => (
  <section className="technologies position-relative" id="technologies">
    <img src={technologiesTop} alt="" className="img-fluid technologiesTop" />
    <div className="container">
      <div className="row justify-content-between align-items-end">
        <div className="col-lg-5 text-md-start text-center"
             data-aos="fade-right" data-aos-delay="50" data-aos-duration="1000">
          {/* <div className="subtitle">Technologies</div> */}
          <div className="trusted-by-title">
            <span>Trusted</span> By
            <br className="d-lg-block d-none" />
            {/* Services for you */}
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="technologies_bubble_wrapper">
            <div className="technologies_bubble_wrapper_inner d-flex justify-content-md-start justify-content-center align-items-center flex-wrap">
              {technologiesBubbles.map((bubble, idx) => (
                <div
                  key={bubble.id}
                  className="technologies_bubble d-flex justify-content-center align-items-start"
                  data-bs-toggle="modal"
                  data-bs-target={`#${bubble.id}`}
                  data-aos={bubble.aos}
                  data-aos-delay={bubble.delay}
                  data-aos-duration="1000"
                >
                  <div className="technologies_bubble_box">
                    <img src={bubble.mainImg} alt="" className="img-fluid updown" />
                    <h5>{bubble.title}</h5>
                    <img src={bubble.bottomImg} alt="" className="img-fluid" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default Technologies;