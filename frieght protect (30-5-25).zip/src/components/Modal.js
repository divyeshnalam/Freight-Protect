// Modal.jsx
import ReactDOM from "react-dom";
import React from "react";
import '../styles.css';

const Modal = ({ title, highlight, content, onClose }) => {
  const modalContent = (
    <div className="custom-modal-overlay" onClick={onClose}>
      <div className="custom-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="custom-close-btn" onClick={onClose}>
          &times;
        </button>
        <div className="custom-modal-header">
            <div className="modal-title">{title}</div>
            {/* {highlight && <div className="modal-subtitle">{highlight}</div>} */}
        </div>
        <div className="custom-modal-body modal-content-style">
          {content}
        </div>
      </div>
    </div>
  );

  return ReactDOM.createPortal(modalContent, document.body);
};

export default Modal;
