import React, { useEffect, useState } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

import topImg from '../assets/img/Process-left-top.png';
import bluePattern from '../assets/img/Process-blue-bg-pattern.png';
import pinkPattern from '../assets/img/Process-pink-bg-pattern.png';
import processLine from '../assets/img/process-line.png';

import process1 from '../assets/img/Process01.png';
import process2 from '../assets/img/Process02.png';
import process3 from '../assets/img/Process03.png';
import process4 from '../assets/img/Process04.png';

import '../styles.css';
import Modal from './Modal'; 

const processSteps = [
  {
    title: "3PL's",
    // subtitle: 'Third-party logistics providers',
    image: process1,
    id: 'storyMapping',
    aos: 'fade-right',
    delay: 50,
    content: (
      <>
        <h5>3PL's</h5>
        <p>We help third-party logistics providers manage operations, optimize routes, and integrate with modern TMS platforms.</p>
      </>
    ),
  },
  {
    title: 'Brokers',
    // subtitle: 'Logistics brokers',
    image: process2,
    id: 'agileDevelopment',
    aos: 'fade-down',
    delay: 70,
    content: (
      <>
        <h5>Brokers</h5>
        <p>We provide tools for brokers to efficiently match carriers and shippers using smart automation and analytics.</p>
      </>
    ),
  },
  {
    title: 'Carriers',
    // subtitle: 'Freight carriers',
    image: process3,
    id: 'uiuxDesign',
    aos: 'fade-down',
    delay: 90,
    content: (
      <>
        <h5>Carriers</h5>
        <p>From fleet management to driver apps, we build solutions tailored to the unique needs of carriers.</p>
      </>
    ),
  },
  {
    title: 'TMS Platforms',
    // subtitle: 'Transportation Mgmt Systems',
    image: process4,
    id: 'codeSprint',
    aos: 'fade-up',
    delay: 110,
    content: (
      <>
        <p>TMS Platforms</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
        <p>We integrate and enhance TMS platforms with custom modules, APIs, and UI improvements.</p>
      </>
    ),
  },
];

const Help = () => {
  const [activeModal, setActiveModal] = useState(null);

  useEffect(() => {
    AOS.init({ once: false, mirror: true, offset: 100, duration: 1000 });
    AOS.refresh();
  }, []);

  const openModal = (id) => setActiveModal(id);
  const closeModal = () => setActiveModal(null);

  return (
    <section className="workProcess position-relative" id="workProcess">
      <img src={topImg} alt="" className="img-fluid workProcess-top-img" />
      <img src={bluePattern} alt="" className="img-fluid bgBluePattern" />

      <div className="work-container">
        <div className="row">
          <div
            className="col-12 text-center"
            data-aos="fade-down"
            data-aos-delay="50"
            data-aos-duration="1000"
          >
            <div className="title">Who <span>We Help</span></div>
          </div>
        </div>
      </div>

      <div className="processFooter position-relative">
        <div className="container-fluid d-lg-block d-none">
          <div className="row justify-content-center workProcessSec">
            <div className="col-12 text-center position-relative">
              <img src={processLine} alt="" className="img-fluid processLine" />
            </div>
          </div>
        </div>

        <div className="processCardWrapper">
          <div className="container d-flex justify-content-between align-items-end flex-wrap">
            {processSteps.map((step, idx) => (
              <div key={step.id} className={`workProcessCard process${idx + 1} text-center`} data-aos={step.aos}>
                <div className="workProcessCard_img" onClick={() => openModal(step.id)}>
                  <img src={step.image} alt={step.title} className="img-fluid updown" />
                </div>
                <div className="workProcessCard_content">
                  <h4>
                    {step.title}
                    <br />
                    <span>{step.subtitle}</span>
                  </h4>
                </div>
              </div>
            ))}

            {processSteps.map((step) =>
              activeModal === step.id ? (
                <Modal
                  key={step.id}
                  title={step.title}
                  highlight={step.subtitle}
                  content={step.content}
                  onClose={closeModal}
                />
              ) : null
            )}
          </div>
        </div>
      </div>

      <img src={pinkPattern} alt="" className="img-fluid bgPinkPattern" />
    </section>
  );
};

export default Help;
