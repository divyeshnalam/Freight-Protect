import React from 'react';
import '../styles.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-bar">
        <div className="footer-left">
          Full stack mobile (iOS, Android) and web app design and development agency
        </div>
        <div className="footer-right">
          Copyright © 2025 Freight Protect - All Rights Reserved.
        </div>
      </div>
    </footer>
  );
}

export default Footer;
