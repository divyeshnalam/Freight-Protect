import React from 'react';
import { Link } from 'react-router-dom';
import logo from '../assets/img/logo.png';
import '../styles.css';

function Header() {
  return (
    <header className="header">
      <div className="header-container">
        <div className="navbar-wrapper">
          <div className="navbar-logo">
            <Link to="/">
              <img src={logo} alt="Logo" className="logo-img" />
            </Link>
          </div>
          <nav className="navbar-header">
            <ul className="nav-menu">
              {/* <li className="nav-item">
                <Link to="/about" className="main-menu">Company</Link>
              </li>
              <li className="nav-item">
                <Link to="/" className="main-menu">Services</Link>
              </li> */}
              <li className="nav-item">
                <Link to="/contact" className="main-menu">Contact Us</Link>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
