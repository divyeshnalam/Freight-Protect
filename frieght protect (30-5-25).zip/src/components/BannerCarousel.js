import React, { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Autoplay, EffectFade } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';
import '../styles.css';
import banner1 from "../assets/img/banner-slider01.png";
// import banner2 from "../assets/img/banner-slider02.png";
// import banner3 from "../assets/img/banner-slider03.png";

function useInView(options) {
  const ref = React.useRef(null);
  const [inView, setInView] = React.useState(false);

  React.useEffect(() => {
    const observer = new window.IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
      },
      options
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [ref, options]);

  return [ref, inView];
}

const slides = [
  {
    image: banner1,
    title: "Ready to save time with FreightProtect",
    text: "See how quickly we can get integrated with your system and saving your support team time - while improving your customers experience when needing quotes"
  }
  // {
  //   image: banner2,
  //   title: "LTL 3PLs & Brokers",
  //   text: "Don’t let the best-laid plans get derailed by unexpected accessorials. Deliver for your clients."
  // },
  // {
  //   image: banner3,
  //   title: "LTL Carriers",
  //   text: "Don’t leave accessorial identification and fee collection to chance. Know before you deliver."
  // }
];

const BannerCarousel = () => {
  const [ref, inView] = useInView({ threshold: 0.2 });
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    if (inView) {
      const timer = setTimeout(() => setAnimate(true), 150);
      return () => clearTimeout(timer);
    } else {
      setAnimate(false);
    }
  }, [inView]);

  return (
    <section className="home_banner" id="homeBanner" ref={ref}>
      <div className="swiper-container-wrapper">
        <Swiper
          modules={[Pagination, Autoplay, EffectFade]}
          pagination={{ clickable: true, el: '.custom-pagination' }}
          effect="fade"
          loop={true}
          autoplay={{
            delay: 5000,
            disableOnInteraction: false,
          }}
          className="swiper banner_combined"
        >
          {slides.map((slide, idx) => (
            <SwiperSlide key={idx}>
              <div className={`slide_content ${animate ? 'animate' : ''}`}>
                <div className="banner_text">
                  <h2>
                    {slide.title.split(" ").slice(0, -1).join(" ")}{' '}
                    <span>{slide.title.split(" ").slice(-1)}</span>
                  </h2>
                  <p>{slide.text}</p>
                </div>
                <div className="banner_image">
                  <img src={slide.image} alt={slide.title} className="img-fluid" />
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
        <div className="custom-pagination"></div>
      </div>
    </section>
  );
};

export default BannerCarousel;


